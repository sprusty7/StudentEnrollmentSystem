package com.example.StudentSpringBootproject.Payment;

import java.util.List;


import org.springframework.stereotype.Service;




@Service
public class PaymentServiceImpl implements PaymentService
{

	private PaymentRepository paymentRepository;
	
	
	public PaymentServiceImpl(PaymentRepository paymentRepository) {
		super();
		this.paymentRepository = paymentRepository;
	}


	@Override
	public List<Payment> getAllPayments() {
		
		return paymentRepository.findAll();
	}


	@Override
	public Payment savePayment(Payment payment) {
		return paymentRepository.save(payment);
	}


	@Override
	public Payment getPaymentById(Long paymentid) {
		return paymentRepository.findById(paymentid).get();
	}

	
}
