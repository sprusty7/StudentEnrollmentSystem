package com.example.StudentSpringBootproject.SC;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;



@Controller
public class ScController {

	private ScService scService;
	

	public ScController(ScService scService) {
		super();
		this.scService = scService;
	}

	@GetMapping("/scs")
	public String listScs(Model model)
	{
		model.addAttribute("scs", scService.getAllScs());
		return "scs";
		
	}
	
	@GetMapping("/scs/new")
	public String createScForm(Model model) {
		
		
		Sc sc = new Sc();
		model.addAttribute("scs", sc);
		return "create_sc";
		
	}
	
	@PostMapping("/scs")
	public String saveSc(@ModelAttribute("sc") Sc sc) {
		scService.saveSc(sc);
		return "redirect:/scs";
	}
	
	@GetMapping("/scs/edit/{classid}")
	public String editScForm(@PathVariable Long classid, Model model) {
		model.addAttribute("sc", scService.getScById(classid));
		return "create_sc";
	}
	
	
	@PostMapping("/scs/{classid}")
	public String updateSc(@PathVariable Long classid,
			@ModelAttribute("sc") Sc sc,
			Model model) {
		Sc existingSc = scService.getScById(classid);
		existingSc.setClassid(classid);
		existingSc.setClassname(sc.getClassname());
		existingSc.setStudentid(sc.getStudentid());
		
		
		
		scService.updateSc(existingSc);
		return "redirect:/scs";	
	}
	

	
		@GetMapping("/scs/{classid}")
		public String deleteSc(@PathVariable Long classid) {
			scService.deleteScById(classid);
			return "redirect:/scs";
		}
	
}
