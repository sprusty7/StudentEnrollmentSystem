package com.example.StudentSpringBootproject.Payment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payment")
public class Payment {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long paymentid;
	
	@Column(name = "username") 
	private String username;
	
	@Column(name = "firstname")
	private String firstname;
	
	@Column(name = "lastname")
	private String lastname;
	
	@Column(name = "paymentfee")
	private String paymentfee;

	@Column(name = "courseid")
	private Long courseid;
	
	
	
	

	public Payment(String username, String firstname, String lastname, String paymentfee, Long courseid) {
		super();
		this.username = username;
		this.firstname = firstname;
		this.lastname = lastname;
		this.paymentfee = paymentfee;
		this.courseid = courseid;
	}

	
	public Payment() {
		// TODO Auto-generated constructor stub
	}


	public Long getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(Long paymentid) {
		this.paymentid = paymentid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPaymentfee() {
		return paymentfee;
	}

	public void setPaymentfee(String paymentfee) {
		this.paymentfee = paymentfee;
	}

	public Long getCourseid() {
		return courseid;
	}

	public void setCourseid(Long courseid) {
		this.courseid = courseid;
	}


	

	
	

}
